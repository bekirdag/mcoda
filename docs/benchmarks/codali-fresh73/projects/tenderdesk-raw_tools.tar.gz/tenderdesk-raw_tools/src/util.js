'use strict';
/** Shared helpers: ids, time, money (integer cents), hashing, cursors, HTML escaping. */
const crypto = require('node:crypto');

function newId(prefix) {
  return prefix + '_' + crypto.randomUUID().replace(/-/g, '').slice(0, 20);
}

function nowIso() {
  return new Date().toISOString();
}

/**
 * Parse a money string into integer cents. Strict: no negatives, max two decimals,
 * optional thousands separators. Returns { cents } or { error }.
 */
function parseMoney(raw) {
  if (typeof raw === 'number') {
    if (!Number.isFinite(raw)) return { error: 'must be a finite number' };
    const cents = Math.round(raw * 100);
    if (cents <= 0) return { error: 'must be greater than zero' };
    if (Math.abs(raw * 100 - cents) > 1e-9) return { error: 'at most two decimal places' };
    return { cents };
  }
  if (typeof raw !== 'string') return { error: 'must be a string or number' };
  const s = raw.trim().replace(/,/g, '');
  if (!/^\d+(\.\d{1,2})?$/.test(s)) return { error: 'use digits with at most two decimals, e.g. 1250.50' };
  const cents = Math.round(Number(s) * 100);
  if (!Number.isSafeInteger(cents)) return { error: 'amount is too large' };
  if (cents <= 0) return { error: 'must be greater than zero' };
  return { cents };
}

function formatMoney(cents) {
  const sign = cents < 0 ? '-' : '';
  const abs = Math.abs(cents);
  const whole = Math.floor(abs / 100).toString();
  const frac = String(abs % 100).padStart(2, '0');
  return sign + whole.replace(/\B(?=(\d{3})+(?!\d))/g, ',') + '.' + frac;
}

/** Canonical JSON (sorted keys) so payload hashes are stable across key order. */
function canonicalJson(value) {
  if (value === null || typeof value !== 'object') return JSON.stringify(value) ?? 'null';
  if (Array.isArray(value)) return '[' + value.map(canonicalJson).join(',') + ']';
  const keys = Object.keys(value).sort();
  return '{' + keys.map((k) => JSON.stringify(k) + ':' + canonicalJson(value[k])).join(',') + '}';
}

function sha256(text) {
  return crypto.createHash('sha256').update(String(text), 'utf8').digest('hex');
}

function payloadHash(obj) {
  return sha256(canonicalJson(obj));
}

function escapeHtml(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

/** Keyset cursor: opaque base64url of the last row's sort key. */
function encodeCursor(obj) {
  return Buffer.from(JSON.stringify(obj), 'utf8').toString('base64url');
}

function decodeCursor(token) {
  if (typeof token !== 'string' || token.length === 0 || token.length > 512) return null;
  try {
    const parsed = JSON.parse(Buffer.from(token, 'base64url').toString('utf8'));
    return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : null;
  } catch (_) {
    return null;
  }
}

function clampInt(raw, { min, max, fallback }) {
  const n = typeof raw === 'number' ? raw : Number.parseInt(String(raw ?? ''), 10);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, Math.trunc(n)));
}

function parseIso(raw) {
  if (typeof raw !== 'string') return null;
  const t = Date.parse(raw);
  if (Number.isNaN(t)) return null;
  return new Date(t).toISOString();
}

module.exports = {
  newId, nowIso, parseMoney, formatMoney, canonicalJson, sha256, payloadHash,
  escapeHtml, encodeCursor, decodeCursor, clampInt, parseIso,
};
