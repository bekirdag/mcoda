'use strict';
/**
 * TenderDesk domain layer: tender lifecycle, sealed bids, dual approval, document workflow,
 * audit trail and keyset pagination. Every mutation is a single transaction: either the row
 * change AND its audit row commit, or nothing at all (rejected operations leave no side effects).
 */
const { newId, nowIso, payloadHash, encodeCursor, decodeCursor, clampInt } = require('./util');
const { transaction } = require('./db');

class ApiError extends Error {
  constructor(status, code, message, details) {
    super(message || code);
    this.status = status;
    this.code = code;
    this.details = details || null;
  }
}

function fail(status, code, message, details) {
  throw new ApiError(status, code, message, details);
}

function audit(db, { tenantId, actorId, action, entityType, entityId, metadata }) {
  db.prepare('INSERT INTO audit_log (tenant_id, actor_id, action, entity_type, entity_id, metadata_json, created_at) VALUES (?,?,?,?,?,?,?)')
    .run(tenantId, actorId, action, entityType, entityId, metadata === undefined ? null : JSON.stringify(metadata), nowIso());
}

function getTenant(db, id) {
  return db.prepare('SELECT id, name, slug, created_at FROM tenants WHERE id = ?').get(id) || null;
}

function getUser(db, id) {
  return db.prepare('SELECT id, tenant_id, email, display_name, role FROM users WHERE id = ?').get(id) || null;
}

/** Tenant isolation: a resource from another tenant is indistinguishable from a missing one. */
function requireTenantRow(db, sql, params, what) {
  const row = db.prepare(sql).get(...params);
  if (!row) fail(404, 'not_found', what + ' was not found in this tenant');
  return row;
}

function requireRole(actor, roles, what) {
  if (!roles.includes(actor.role)) {
    fail(403, 'forbidden', 'Your role (' + actor.role + ') may not ' + what);
  }
}

/* ------------------------------------------------------------------ tenders */

function listTenders(db, actor, query) {
  const limit = clampInt(query.limit, { min: 1, max: 100, fallback: 20 });
  const cursor = query.cursor ? decodeCursor(query.cursor) : null;
  if (query.cursor && !cursor) fail(400, 'bad_cursor', 'cursor is not valid');
  const state = query.state;
  if (state !== undefined && !['draft', 'open', 'closed', 'awarded'].includes(state)) {
    fail(400, 'bad_state', 'state must be one of draft, open, closed, awarded');
  }
  const where = ['t.tenant_id = ?'];
  const params = [actor.tenant_id];
  if (state) { where.push('t.state = ?'); params.push(state); }
  if (cursor && cursor.id) { where.push('t.id > ?'); params.push(String(cursor.id)); }
  const rows = db.prepare(
    'SELECT t.id, t.title, t.state, t.budget_cents, t.version, t.created_at, t.updated_at, t.opens_at, t.closes_at, t.opened_at, t.closed_at, ' +
    '(SELECT COUNT(*) FROM bids b WHERE b.tender_id = t.id) AS bid_count ' +
    'FROM tenders t WHERE ' + where.join(' AND ') + ' ORDER BY t.id ASC LIMIT ?'
  ).all(...params, limit + 1);
  const hasMore = rows.length > limit;
  const items = hasMore ? rows.slice(0, limit) : rows;
  return {
    items,
    nextCursor: hasMore ? encodeCursor({ id: items[items.length - 1].id }) : null,
  };
}

function getTender(db, actor, tenderId, { includeLines = true } = {}) {
  const tender = requireTenantRow(
    db, 'SELECT * FROM tenders WHERE id = ? AND tenant_id = ?', [tenderId, actor.tenant_id], 'Tender');
  const sealed = isSealed(tender);
  const bids = db.prepare(
    'SELECT b.id, b.supplier_id, b.price_cents, b.delivery_days, b.note, b.created_at, b.payload_hash ' +
    'FROM bids b WHERE b.tender_id = ? ORDER BY b.created_at ASC').all(tenderId).map((b) => {
    const supplier = db.prepare('SELECT display_name FROM users WHERE id = ?').get(b.supplier_id);
    const view = { id: b.id, supplier_id: b.supplier_id, supplier_name: supplier ? supplier.display_name : null, created_at: b.created_at };
    if (!sealed) {
      view.price_cents = b.price_cents;
      view.delivery_days = b.delivery_days;
      view.note = b.note;
    }
    return view;
  });
  const lines = includeLines
    ? db.prepare('SELECT id, name, quantity, unit, position FROM tender_lines WHERE tender_id = ? ORDER BY position ASC').all(tenderId)
    : [];
  const award = db.prepare('SELECT * FROM awards WHERE tender_id = ?').get(tenderId) || null;
  const approvals = award
    ? db.prepare('SELECT a.id, a.approver_id, u.display_name, a.created_at FROM award_approvals a JOIN users u ON u.id = a.approver_id WHERE a.award_id = ? ORDER BY a.created_at ASC').all(award.id)
    : [];
  return {
    tender: publicTender(tender),
    sealed,
    lines,
    bids,
    bidCount: bids.length,
    award: award ? { ...award } : null,
    approvals,
  };
}

/** Sealed = bids exist and the tender has not closed yet: amounts are hidden from everyone. */
function isSealed(tender) {
  return tender.state === 'draft' || tender.state === 'open';
}

function publicTender(t) {
  return {
    id: t.id, title: t.title, summary: t.summary, budget_cents: t.budget_cents, state: t.state,
    version: t.version, created_at: t.created_at, updated_at: t.updated_at,
    opens_at: t.opens_at, closes_at: t.closes_at, opened_at: t.opened_at, closed_at: t.closed_at,
  };
}

function createTender(db, actor, input) {
  requireRole(actor, ['buyer'], 'create tenders');
  const title = String(input.title || '').trim();
  if (title.length < 3) fail(400, 'validation', 'title must be at least 3 characters');
  if (title.length > 200) fail(400, 'validation', 'title must be at most 200 characters');
  if (typeof input.budget_cents !== 'number' || !Number.isSafeInteger(input.budget_cents) || input.budget_cents <= 0) {
    fail(400, 'validation', 'budget_cents must be a positive integer number of cents');
  }
  const lines = Array.isArray(input.lines) ? input.lines : [];
  if (lines.length > 50) fail(400, 'validation', 'a tender may have at most 50 line items');
  for (const line of lines) {
    if (!line || typeof line.name !== 'string' || line.name.trim().length === 0) fail(400, 'validation', 'each line item needs a name');
    if (!Number.isInteger(line.quantity) || line.quantity <= 0) fail(400, 'validation', 'each line item needs a positive integer quantity');
  }
  const id = newId('tnd');
  const ts = nowIso();
  return transaction(db, () => {
    db.prepare('INSERT INTO tenders (id, tenant_id, title, summary, budget_cents, state, version, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?)')
      .run(id, actor.tenant_id, title, String(input.summary || '').trim().slice(0, 2000), input.budget_cents, 'draft', 1, ts, ts);
    const insertLine = db.prepare('INSERT INTO tender_lines (id, tender_id, name, quantity, unit, position) VALUES (?,?,?,?,?,?)');
    lines.forEach((line, i) => insertLine.run(newId('ln'), id, line.name.trim().slice(0, 200), line.quantity, String(line.unit || 'unit').slice(0, 24), i + 1));
    audit(db, { tenantId: actor.tenant_id, actorId: actor.id, action: 'tender.create', entityType: 'tender', entityId: id, metadata: { title, budget_cents: input.budget_cents, lines: lines.length } });
    return getTender(db, actor, id);
  });
}

function updateTender(db, actor, tenderId, input) {
  requireRole(actor, ['buyer'], 'edit tenders');
  const current = requireTenantRow(db, 'SELECT * FROM tenders WHERE id = ? AND tenant_id = ?', [tenderId, actor.tenant_id], 'Tender');
  if (current.state !== 'draft') fail(409, 'invalid_state', 'only draft tenders can be edited (state: ' + current.state + ')');
  if (typeof input.version !== 'number' || !Number.isInteger(input.version)) fail(400, 'validation', 'version is required for optimistic concurrency');
  if (input.version !== current.version) {
    fail(409, 'conflict', 'this tender was modified by someone else (expected version ' + input.version + ', current ' + current.version + ')',
      { currentVersion: current.version });
  }
  const title = input.title === undefined ? current.title : String(input.title).trim();
  if (title.length < 3) fail(400, 'validation', 'title must be at least 3 characters');
  const budget = input.budget_cents === undefined ? current.budget_cents : input.budget_cents;
  if (!Number.isSafeInteger(budget) || budget <= 0) fail(400, 'validation', 'budget_cents must be a positive integer number of cents');
  const ts = nowIso();
  return transaction(db, () => {
    db.prepare('UPDATE tenders SET title = ?, summary = ?, budget_cents = ?, version = version + 1, updated_at = ? WHERE id = ?')
      .run(title, input.summary === undefined ? current.summary : String(input.summary).trim().slice(0, 2000), budget, ts, tenderId);
    if (Array.isArray(input.lines)) {
      if (input.lines.length > 50) fail(400, 'validation', 'a tender may have at most 50 line items');
      for (const line of input.lines) {
        if (!line || typeof line.name !== 'string' || !line.name.trim()) fail(400, 'validation', 'each line item needs a name');
        if (!Number.isInteger(line.quantity) || line.quantity <= 0) fail(400, 'validation', 'each line item needs a positive integer quantity');
      }
      db.prepare('DELETE FROM tender_lines WHERE tender_id = ?').run(tenderId);
      const insertLine = db.prepare('INSERT INTO tender_lines (id, tender_id, name, quantity, unit, position) VALUES (?,?,?,?,?,?)');
      input.lines.forEach((line, i) => insertLine.run(newId('ln'), tenderId, line.name.trim().slice(0, 200), line.quantity, String(line.unit || 'unit').slice(0, 24), i + 1));
    }
    audit(db, { tenantId: actor.tenant_id, actorId: actor.id, action: 'tender.update', entityType: 'tender', entityId: tenderId, metadata: { version: current.version + 1 } });
    return getTender(db, actor, tenderId);
  });
}

/** draft -> open (sealed bidding window starts) */
function openTender(db, actor, tenderId, input) {
  requireRole(actor, ['buyer'], 'open tenders');
  const current = requireTenantRow(db, 'SELECT * FROM tenders WHERE id = ? AND tenant_id = ?', [tenderId, actor.tenant_id], 'Tender');
  if (current.state !== 'draft') fail(409, 'invalid_state', 'only draft tenders can be opened (state: ' + current.state + ')');
  const lines = db.prepare('SELECT COUNT(*) AS n FROM tender_lines WHERE tender_id = ?').get(tenderId).n;
  if (lines === 0) fail(409, 'invalid_state', 'add at least one line item before opening a tender');
  const closesAt = input && input.closes_at ? input.closes_at : null;
  const ts = nowIso();
  return transaction(db, () => {
    db.prepare("UPDATE tenders SET state = 'open', version = version + 1, updated_at = ?, opened_at = ?, closes_at = ? WHERE id = ?")
      .run(ts, ts, closesAt, tenderId);
    audit(db, { tenantId: actor.tenant_id, actorId: actor.id, action: 'tender.open', entityType: 'tender', entityId: tenderId, metadata: { closes_at: closesAt } });
    return getTender(db, actor, tenderId);
  });
}

/** open -> closed: bids are unsealed and become visible to the buying side. */
function closeTender(db, actor, tenderId) {
  requireRole(actor, ['buyer'], 'close tenders');
  const current = requireTenantRow(db, 'SELECT * FROM tenders WHERE id = ? AND tenant_id = ?', [tenderId, actor.tenant_id], 'Tender');
  if (current.state !== 'open') fail(409, 'invalid_state', 'only open tenders can be closed (state: ' + current.state + ')');
  const ts = nowIso();
  return transaction(db, () => {
    db.prepare("UPDATE tenders SET state = 'closed', version = version + 1, updated_at = ?, closed_at = ? WHERE id = ?").run(ts, ts, tenderId);
    audit(db, { tenantId: actor.tenant_id, actorId: actor.id, action: 'tender.close', entityType: 'tender', entityId: tenderId });
    return getTender(db, actor, tenderId);
  });
}

/* --------------------------------------------------------------------- bids */

function listOpenTendersForSuppliers(db, actor) {
  return db.prepare(
    "SELECT t.id, t.title, t.summary, t.budget_cents, t.closes_at, t.opened_at, " +
    "EXISTS(SELECT 1 FROM bids b WHERE b.tender_id = t.id AND b.supplier_id = ?) AS has_own_bid " +
    "FROM tenders t WHERE t.tenant_id = ? AND t.state = 'open' ORDER BY t.id ASC").all(actor.id, actor.tenant_id);
}

function submitBid(db, actor, tenderId, input) {
  requireRole(actor, ['supplier'], 'submit bids');
  const tender = requireTenantRow(db, 'SELECT * FROM tenders WHERE id = ? AND tenant_id = ?', [tenderId, actor.tenant_id], 'Tender');
  if (tender.state !== 'open') fail(409, 'sealed', 'bidding is not open for this tender (state: ' + tender.state + ')');
  if (tender.closes_at && Date.parse(tender.closes_at) <= Date.now()) fail(409, 'sealed', 'the bidding window for this tender has already elapsed');
  if (typeof input.price_cents !== 'number' || !Number.isSafeInteger(input.price_cents) || input.price_cents <= 0) {
    fail(400, 'validation', 'price_cents must be a positive integer number of cents');
  }
  if (!Number.isInteger(input.delivery_days) || input.delivery_days <= 0) fail(400, 'validation', 'delivery_days must be a positive integer');
  const idempotencyKey = String(input.idempotency_key || '').trim();
  if (!idempotencyKey) fail(400, 'validation', 'idempotency_key is required so retries cannot create duplicate bids');
  const payload = { price_cents: input.price_cents, delivery_days: input.delivery_days, note: String(input.note || '').trim().slice(0, 1000) };
  const hash = payloadHash(payload);

  const existingByKey = db.prepare('SELECT id, payload_hash FROM bids WHERE tender_id = ? AND idempotency_key = ?').get(tenderId, idempotencyKey);
  if (existingByKey) {
    if (existingByKey.payload_hash === hash) {
      // Replay of the exact same submission: return the original bid, no new side effects.
      return { bid: db.prepare('SELECT * FROM bids WHERE id = ?').get(existingByKey.id), replayed: true };
    }
    fail(409, 'idempotency_conflict', 'that idempotency key was already used with a different bid payload');
  }
  const existingBySupplier = db.prepare('SELECT id FROM bids WHERE tender_id = ? AND supplier_id = ?').get(tenderId, actor.id);
  if (existingBySupplier) fail(409, 'duplicate_bid', 'you have already submitted a bid on this tender; bids are sealed and cannot be replaced');

  const id = newId('bid');
  try {
    transaction(db, () => {
      db.prepare('INSERT INTO bids (id, tender_id, supplier_id, price_cents, delivery_days, note, idempotency_key, payload_hash, created_at) VALUES (?,?,?,?,?,?,?,?,?)')
        .run(id, tenderId, actor.id, payload.price_cents, payload.delivery_days, payload.note, idempotencyKey, hash, nowIso());
      audit(db, { tenantId: actor.tenant_id, actorId: actor.id, action: 'bid.submit', entityType: 'bid', entityId: id, metadata: { tender_id: tenderId, price_cents: payload.price_cents, delivery_days: payload.delivery_days } });
    });
  } catch (err) {
    if (String(err.message).includes('UNIQUE constraint')) {
      fail(409, 'duplicate_bid', 'a bid for this tender already exists (race rejected)');
    }
    throw err;
  }
  return { bid: db.prepare('SELECT * FROM bids WHERE id = ?').get(id), replayed: false };
}

function ownBid(db, actor, tenderId) {
  return db.prepare('SELECT id, price_cents, delivery_days, note, created_at FROM bids WHERE tender_id = ? AND supplier_id = ?').get(tenderId, actor.id) || null;
}

/* ------------------------------------------------------------ dual approval */

function nominateAward(db, actor, tenderId, input) {
  requireRole(actor, ['buyer'], 'nominate an award');
  const tender = requireTenantRow(db, 'SELECT * FROM tenders WHERE id = ? AND tenant_id = ?', [tenderId, actor.tenant_id], 'Tender');
  if (tender.state !== 'closed') fail(409, 'invalid_state', 'bids must be closed before an award can be nominated (state: ' + tender.state + ')');
  const bidId = String(input.bid_id || '');
  const bid = db.prepare('SELECT * FROM bids WHERE id = ? AND tender_id = ?').get(bidId, tenderId);
  if (!bid) fail(404, 'not_found', 'that bid does not belong to this tender');
  const existing = db.prepare('SELECT id FROM awards WHERE tender_id = ?').get(tenderId);
  if (existing) fail(409, 'already_nominated', 'this tender already has an award nomination');
  const id = newId('awd');
  return transaction(db, () => {
    db.prepare('INSERT INTO awards (id, tender_id, bid_id, status, created_by, created_at) VALUES (?,?,?,?,?,?)')
      .run(id, tenderId, bidId, 'pending', actor.id, nowIso());
    audit(db, { tenantId: actor.tenant_id, actorId: actor.id, action: 'award.nominate', entityType: 'award', entityId: id, metadata: { tender_id: tenderId, bid_id: bidId, price_cents: bid.price_cents } });
    return getTender(db, actor, tenderId);
  });
}

/**
 * Dual approval: an award becomes approved only when two DIFFERENT approvers have signed it,
 * and the approver who nominated the award cannot count as one of the two.
 */
function approveAward(db, actor, awardId) {
  requireRole(actor, ['approver'], 'approve awards');
  const award = requireTenantRow(db, 'SELECT * FROM awards WHERE id = ? AND tenant_id = ?', [awardId, actor.tenant_id], 'Award');
  if (award.status === 'approved') fail(409, 'already_approved', 'this award is already approved');
  if (award.created_by === actor.id) fail(403, 'self_approval', 'the person who nominated an award cannot approve it');
  const already = db.prepare('SELECT id FROM award_approvals WHERE award_id = ? AND approver_id = ?').get(awardId, actor.id);
  if (already) fail(409, 'already_signed', 'you have already signed this award');

  return transaction(db, () => {
    db.prepare('INSERT INTO award_approvals (id, award_id, approver_id, created_at) VALUES (?,?,?,?)').run(newId('apv'), awardId, actor.id, nowIso());
    audit(db, { tenantId: actor.tenant_id, actorId: actor.id, action: 'award.approve', entityType: 'award', entityId: awardId, metadata: { signatures: countSignatures(db, awardId) } });
    const signatures = countSignatures(db, awardId);
    if (signatures >= 2) {
      const ts = nowIso();
      db.prepare("UPDATE awards SET status = 'approved', approved_at = ? WHERE id = ?").run(ts, awardId);
      db.prepare("UPDATE tenders SET state = 'awarded', version = version + 1, updated_at = ? WHERE id = ?").run(ts, award.tender_id);
      audit(db, { tenantId: actor.tenant_id, actorId: actor.id, action: 'award.final', entityType: 'award', entityId: awardId, metadata: { tender_id: award.tender_id, signatures } });
    }
    return { award: db.prepare('SELECT * FROM awards WHERE id = ?').get(awardId), signatures, needed: 2 };
  });
}

function countSignatures(db, awardId) {
  return db.prepare('SELECT COUNT(*) AS n FROM award_approvals WHERE award_id = ?').get(awardId).n;
}

/* ------------------------------------------------------- document workflow */

function listDocuments(db, actor, query) {
  const limit = clampInt(query.limit, { min: 1, max: 100, fallback: 20 });
  const cursor = query.cursor ? decodeCursor(query.cursor) : null;
  if (query.cursor && !cursor) fail(400, 'bad_cursor', 'cursor is not valid');
  const where = ['d.tenant_id = ?'];
  const params = [actor.tenant_id];
  if (query.state) {
    if (!['draft', 'in_review', 'published', 'rejected'].includes(query.state)) fail(400, 'bad_state', 'state must be one of draft, in_review, published, rejected');
    where.push('d.state = ?'); params.push(query.state);
  }
  if (cursor && cursor.id) { where.push('d.id > ?'); params.push(String(cursor.id)); }
  const rows = db.prepare('SELECT d.id, d.title, d.state, d.version, d.updated_at, d.published_at, u.display_name AS author FROM documents d JOIN users u ON u.id = d.created_by WHERE ' + where.join(' AND ') + ' ORDER BY d.id ASC LIMIT ?').all(...params, limit + 1);
  const hasMore = rows.length > limit;
  const items = hasMore ? rows.slice(0, limit) : rows;
  return { items, nextCursor: hasMore ? encodeCursor({ id: items[items.length - 1].id }) : null };
}

function getDocument(db, actor, id) {
  const doc = requireTenantRow(db, 'SELECT d.*, u.display_name AS author FROM documents d JOIN users u ON u.id = d.created_by WHERE d.id = ? AND d.tenant_id = ?', [id, actor.tenant_id], 'Document');
  return doc;
}

function createDocument(db, actor, input) {
  requireRole(actor, ['editor', 'author'], 'create documents');
  const title = String(input.title || '').trim();
  if (title.length < 3) fail(400, 'validation', 'title must be at least 3 characters');
  const id = newId('doc');
  const ts = nowIso();
  return transaction(db, () => {
    db.prepare('INSERT INTO documents (id, tenant_id, title, body, state, version, created_by, updated_at) VALUES (?,?,?,?,?,?,?,?)')
      .run(id, actor.tenant_id, title, String(input.body || ''), 'draft', 1, actor.id, ts);
    audit(db, { tenantId: actor.tenant_id, actorId: actor.id, action: 'document.create', entityType: 'document', entityId: id, metadata: { title } });
    return getDocument(db, actor, id);
  });
}

/** Editors/authors may change a document only while it is a draft or was rejected. */
function updateDocument(db, actor, id, input) {
  requireRole(actor, ['editor', 'author'], 'edit documents');
  const doc = requireTenantRow(db, 'SELECT * FROM documents WHERE id = ? AND tenant_id = ?', [id, actor.tenant_id], 'Document');
  if (doc.state !== 'draft' && doc.state !== 'rejected') fail(409, 'immutable', 'a ' + doc.state + ' document cannot be edited');
  if (typeof input.version !== 'number' || !Number.isInteger(input.version)) fail(400, 'validation', 'version is required for optimistic concurrency');
  if (input.version !== doc.version) fail(409, 'conflict', 'this document changed while you were editing (expected ' + input.version + ', current ' + doc.version + ')', { currentVersion: doc.version });
  const title = input.title === undefined ? doc.title : String(input.title).trim();
  if (title.length < 3) fail(400, 'validation', 'title must be at least 3 characters');
  return transaction(db, () => {
    db.prepare('UPDATE documents SET title = ?, body = ?, state = ?, version = version + 1, updated_at = ? WHERE id = ?')
      .run(title, input.body === undefined ? doc.body : String(input.body), 'draft', nowIso(), id);
    audit(db, { tenantId: actor.tenant_id, actorId: actor.id, action: 'document.update', entityType: 'document', entityId: id, metadata: { version: doc.version + 1 } });
    return getDocument(db, actor, id);
  });
}

function submitDocumentForReview(db, actor, id, input) {
  requireRole(actor, ['editor', 'author'], 'submit documents for review');
  const doc = requireTenantRow(db, 'SELECT * FROM documents WHERE id = ? AND tenant_id = ?', [id, actor.tenant_id], 'Document');
  if (doc.state !== 'draft' && doc.state !== 'rejected') fail(409, 'immutable', 'only draft or rejected documents can be submitted for review');
  if (typeof input.version !== 'number' || input.version !== doc.version) fail(409, 'conflict', 'the document changed; reload before submitting');
  return transaction(db, () => {
    db.prepare("UPDATE documents SET state = 'in_review', version = version + 1, updated_at = ? WHERE id = ?").run(nowIso(), id);
    audit(db, { tenantId: actor.tenant_id, actorId: actor.id, action: 'document.submit_review', entityType: 'document', entityId: id });
    return getDocument(db, actor, id);
  });
}

/** Reviewers approve (publish) or reject. Published documents become immutable. */
function reviewDocument(db, actor, id, decision) {
  requireRole(actor, ['reviewer'], 'review documents');
  if (!['approve', 'reject'].includes(decision)) fail(400, 'validation', 'decision must be approve or reject');
  const doc = requireTenantRow(db, 'SELECT * FROM documents WHERE id = ? AND tenant_id = ?', [id, actor.tenant_id], 'Document');
  if (doc.state !== 'in_review') fail(409, 'invalid_state', 'only documents in review can be reviewed (state: ' + doc.state + ')');
  const ts = nowIso();
  return transaction(db, () => {
    if (decision === 'approve') {
      db.prepare("UPDATE documents SET state = 'published', published_at = ?, version = version + 1, updated_at = ? WHERE id = ?").run(ts, ts, id);
    } else {
      db.prepare("UPDATE documents SET state = 'rejected', version = version + 1, updated_at = ? WHERE id = ?").run(ts, id);
    }
    audit(db, { tenantId: actor.tenant_id, actorId: actor.id, action: 'document.' + decision, entityType: 'document', entityId: id });
    return getDocument(db, actor, id);
  });
}

/* -------------------------------------------------------------------- audit */

function listAudit(db, actor, query) {
  const limit = clampInt(query.limit, { min: 1, max: 200, fallback: 50 });
  const after = Number.isFinite(Number(query.after)) && Number(query.after) > 0 ? Number(query.after) : 0;
  const rows = db.prepare(
    'SELECT a.id, a.action, a.entity_type, a.entity_id, a.metadata_json, a.created_at, u.display_name AS actor ' +
    'FROM audit_log a JOIN users u ON u.id = a.actor_id WHERE a.tenant_id = ? AND a.id > ? ORDER BY a.id ASC LIMIT ?'
  ).all(actor.tenant_id, after, limit);
  return {
    items: rows.map((r) => ({ ...r, metadata: r.metadata_json ? JSON.parse(r.metadata_json) : null })),
    lastId: rows.length ? rows[rows.length - 1].id : after,
  };
}

module.exports = {
  ApiError, fail, audit, getTenant, getUser, requireTenantRow, requireRole,
  listTenders, getTender, createTender, updateTender, openTender, closeTender, isSealed, publicTender,
  listOpenTendersForSuppliers, submitBid, ownBid,
  nominateAward, approveAward, countSignatures,
  listDocuments, getDocument, createDocument, updateDocument, submitDocumentForReview, reviewDocument,
  listAudit,
};
