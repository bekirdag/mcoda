'use strict';
/** Authentication: scrypt password hashing + opaque bearer sessions with CSRF tokens. */
const crypto = require('node:crypto');
const { newId, nowIso, sha256 } = require('./util');

const SESSION_TTL_MS = 1000 * 60 * 60 * 12; // 12 hours

function hashPassword(password) {
  const salt = crypto.randomBytes(16);
  const derived = crypto.scryptSync(password, salt, 32);
  return 'scrypt$' + salt.toString('hex') + '$' + derived.toString('hex');
}

function verifyPassword(password, stored) {
  if (typeof stored !== 'string') return false;
  const parts = stored.split('$');
  if (parts.length !== 3 || parts[0] !== 'scrypt') return false;
  const salt = Buffer.from(parts[1], 'hex');
  const expected = Buffer.from(parts[2], 'hex');
  const derived = crypto.scryptSync(password, salt, expected.length);
  return crypto.timingSafeEqual(derived, expected);
}

function newSessionToken() {
  return crypto.randomBytes(32).toString('base64url');
}

function createSession(db, user) {
  const token = newSessionToken();
  const csrf = crypto.randomBytes(24).toString('base64url');
  const createdAt = nowIso();
  const expiresAt = new Date(Date.now() + SESSION_TTL_MS).toISOString();
  db.prepare('INSERT INTO sessions (token_hash, user_id, tenant_id, csrf_token, created_at, expires_at) VALUES (?,?,?,?,?,?)')
    .run(sha256(token), user.id, user.tenant_id, csrf, createdAt, expiresAt);
  return { token, csrf, expiresAt };
}

function lookupSession(db, token) {
  if (typeof token !== 'string' || token.length === 0) return null;
  const row = db.prepare(
    'SELECT s.token_hash, s.user_id, s.tenant_id, s.csrf_token, s.expires_at, u.email, u.display_name, u.role, t.name AS tenant_name ' +
    'FROM sessions s JOIN users u ON u.id = s.user_id JOIN tenants t ON t.id = s.tenant_id WHERE s.token_hash = ?'
  ).get(sha256(token));
  if (!row) return null;
  if (Date.parse(row.expires_at) <= Date.now()) {
    db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(row.token_hash);
    return null;
  }
  return row;
}

function destroySession(db, token) {
  if (typeof token !== 'string' || !token) return false;
  const info = db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(sha256(token));
  return Number(info.changes) > 0;
}

function createUser(db, { tenantId, email, displayName, role, password }) {
  const id = newId('usr');
  db.prepare('INSERT INTO users (id, tenant_id, email, display_name, role, password_hash, created_at) VALUES (?,?,?,?,?,?,?)')
    .run(id, tenantId, String(email).toLowerCase().trim(), displayName, role, hashPassword(password), nowIso());
  return id;
}

module.exports = { hashPassword, verifyPassword, createSession, lookupSession, destroySession, createUser, SESSION_TTL_MS };
