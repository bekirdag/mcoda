'use strict';
/**
 * TenderDesk persistence layer.
 * Uses the Node 22 built-in `node:sqlite` driver so the project has zero native/npm dependencies.
 * Migrations are idempotent and the audit trail is append-only (enforced by DB triggers).
 */
const { DatabaseSync } = require('node:sqlite');
const fs = require('node:fs');
const path = require('node:path');

const SCHEMA = `
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS tenants (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  tenant_id TEXT NOT NULL REFERENCES tenants(id),
  email TEXT NOT NULL UNIQUE,
  display_name TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('buyer','approver','supplier','editor','author','reviewer')),
  password_hash TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS sessions (
  token_hash TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id),
  tenant_id TEXT NOT NULL REFERENCES tenants(id),
  csrf_token TEXT NOT NULL,
  created_at TEXT NOT NULL,
  expires_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS tenders (
  id TEXT PRIMARY KEY,
  tenant_id TEXT NOT NULL REFERENCES tenants(id),
  title TEXT NOT NULL,
  summary TEXT NOT NULL DEFAULT '',
  budget_cents INTEGER NOT NULL CHECK (budget_cents > 0),
  state TEXT NOT NULL CHECK (state IN ('draft','open','closed','awarded')),
  version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  opens_at TEXT,
  closes_at TEXT,
  opened_at TEXT,
  closed_at TEXT
);

CREATE TABLE IF NOT EXISTS tender_lines (
  id TEXT PRIMARY KEY,
  tender_id TEXT NOT NULL REFERENCES tenders(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  quantity INTEGER NOT NULL CHECK (quantity > 0),
  unit TEXT NOT NULL DEFAULT 'unit',
  position INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS bids (
  id TEXT PRIMARY KEY,
  tender_id TEXT NOT NULL REFERENCES tenders(id) ON DELETE CASCADE,
  supplier_id TEXT NOT NULL REFERENCES users(id),
  price_cents INTEGER NOT NULL CHECK (price_cents > 0),
  delivery_days INTEGER NOT NULL CHECK (delivery_days > 0),
  note TEXT NOT NULL DEFAULT '',
  idempotency_key TEXT NOT NULL,
  payload_hash TEXT NOT NULL,
  created_at TEXT NOT NULL,
  UNIQUE (tender_id, supplier_id),
  UNIQUE (tender_id, idempotency_key)
);

CREATE TABLE IF NOT EXISTS awards (
  id TEXT PRIMARY KEY,
  tender_id TEXT NOT NULL REFERENCES tenders(id) ON DELETE CASCADE,
  bid_id TEXT NOT NULL REFERENCES bids(id),
  status TEXT NOT NULL CHECK (status IN ('pending','approved')),
  created_by TEXT NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL,
  approved_at TEXT,
  UNIQUE (tender_id)
);

CREATE TABLE IF NOT EXISTS award_approvals (
  id TEXT PRIMARY KEY,
  award_id TEXT NOT NULL REFERENCES awards(id) ON DELETE CASCADE,
  approver_id TEXT NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL,
  UNIQUE (award_id, approver_id)
);

CREATE TABLE IF NOT EXISTS documents (
  id TEXT PRIMARY KEY,
  tenant_id TEXT NOT NULL REFERENCES tenants(id),
  title TEXT NOT NULL,
  body TEXT NOT NULL DEFAULT '',
  state TEXT NOT NULL CHECK (state IN ('draft','in_review','published','rejected')),
  version INTEGER NOT NULL DEFAULT 1,
  created_by TEXT NOT NULL REFERENCES users(id),
  updated_at TEXT NOT NULL,
  published_at TEXT
);

CREATE TABLE IF NOT EXISTS audit_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tenant_id TEXT NOT NULL REFERENCES tenants(id),
  actor_id TEXT NOT NULL REFERENCES users(id),
  action TEXT NOT NULL,
  entity_type TEXT NOT NULL,
  entity_id TEXT NOT NULL,
  metadata_json TEXT,
  created_at TEXT NOT NULL
);

CREATE TRIGGER IF NOT EXISTS audit_no_update BEFORE UPDATE ON audit_log
BEGIN SELECT RAISE(ABORT, 'audit_log is append-only'); END;
CREATE TRIGGER IF NOT EXISTS audit_no_delete BEFORE DELELETE ON audit_log
BEGIN SELECT RAISE(ABORT, 'audit_log is append-only'); END;

CREATE INDEX IF NOT EXISTS idx_tenders_tenant ON tenders(tenant_id, state);
CREATE INDEX IF NOT EXISTS idx_bids_tender ON bids(tender_id);
CREATE INDEX IF NOT EXISTS idx_audit_tenant ON audit_log(tenant_id, id);
CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_documents_tenant ON documents(tenant_id, state);
`;

function openDatabase(dbPath) {
  if (dbPath !== ':memory:') {
    const abs = path.resolve(dbPath);
    fs.mkdirSync(path.dirname(abs), { recursive: true });
  }
  const db = new DatabaseSync(dbPath);
  db.exec('PRAGMA journal_mode = WAL;');
  db.exec('PRAGMA busy_timeout = 5000;');
  db.exec('PRAGMA foreign_keys = ON;');
  db.exec(SCHEMA);
  return db;
}

/**
 * Run `fn` inside an IMMEDIATE transaction. Any throw rolls everything back, so a
 * rejected operation leaves no side effects (including no audit row).
 */
function transaction(db, fn) {
  if (db.inTransaction) db.exec('BEGIN IMMEDIATE');
  else db.exec('BEGIN IMMEDIATE');
  try {
    const out = fn();
    db.exec('COMMIT');
    return out;
  } catch (err) {
    try { db.exec('ROLLBACK'); } catch (_) { /* best effort */ }
    throw err;
  }
}

module.exports = { openDatabase, transaction, SCHEMA };
