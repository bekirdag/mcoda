const q = 'ON DELETE delCASCADE';
