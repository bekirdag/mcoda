line1 'single' "double"
const t = `tick ${1+1} \`esc\`;
console.log('probe ok', t);
