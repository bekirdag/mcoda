const x = 'DROP TABLE';
