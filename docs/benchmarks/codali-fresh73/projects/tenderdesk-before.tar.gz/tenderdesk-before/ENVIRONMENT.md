# Build environment
Linux x86_64,Node22,npm,pnpm,Python3,git,rg and isolated shell are available. All project writes must stay in this workspace. Shell network is enabled for public dependency downloads. Use run_shell with command and args separately and explicit writePaths:["."] for installs/build output. Package-cache environment variables (NPM_CONFIG_CACHE, GRADLE_USER_HOME, PIP_CACHE_DIR, CARGO_HOME) point to private persistent caches outside source; preserve them. Shell HOME and /tmp are temporary and contain no host credentials.

You may use discoverable tools,including Docdex and browser tools. No paid services,host administration or external account creation. RFP.md and ENVIRONMENT.md are immutable inputs. Source starts empty; build a real app,not a report.

Apple Xcode/macOS is not available in this Linux build environment. Native iOS compile/simulator tests cannot run here. Only if the RFP explicitly requests a native iOS app, provide its complete native project and tests, disclose this validation limitation, and do not substitute a web app. For every other platform, follow the RFP platform requirements. External evaluation may later use a Mac.
